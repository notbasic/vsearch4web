from setuptools import setup

setup(
    name='vsearch',
    version='1.0',
    description='THE HEAD FIRST PYTHON SEARCH TOOLs',
    author='HF Python 2e',
    author_email='headfirstlabs.com',
    py_modules=['vsearch'],
)
